#include <lpc21xx.h>

#include "header.h"


int LDR_sensor(void)

{

    unsigned int adcout, temp;


    /* Read ADC Channel 1 */

    adcout = adc_read(1);


    temp = (adcout * 100) / 1023;


    uart0_tx_string("Light Level : ");


    if(temp >= 70)

    {

        uart0_tx_string("HIGH\r\n");

        uart0_tx_string("Status : SUNNY\r\n");


        /* Green LED ON */

        IOCLR0 = green;

        IOSET0 = yellow | red;


        lcd_cmd(0x01);

        lcd_cmd(0x80);

        lcd_string("Light : HIGH");

        lcd_cmd(0xC0);

        lcd_string("Sunny Field");

    }

    else if(temp >= 30)

    {

        uart0_tx_string("MEDIUM\r\n");

        uart0_tx_string("Status : NORMAL\r\n");


        /* Green LED ON */

        IOCLR0 = green;

        IOSET0 = yellow | red;


        lcd_cmd(0x01);

        lcd_cmd(0x80);

        lcd_string("Light : MEDIUM");

        lcd_cmd(0xC0);

        lcd_string("Normal Day");

    }

    else

    {

        uart0_tx_string("LOW\r\n");

        uart0_tx_string("Status : CLOUDY\r\n");


        /* Yellow LED ON */

        IOCLR0 = yellow;

        IOSET0 = green | red;


        lcd_cmd(0x01);

        lcd_cmd(0x80);

        lcd_string("Light : LOW");

        lcd_cmd(0xC0);

        lcd_string("Cloudy Sky");

    }


    uart0_tx_string("-----------------------------------\r\n");


    delay_ms(100);

		return temp;


}

