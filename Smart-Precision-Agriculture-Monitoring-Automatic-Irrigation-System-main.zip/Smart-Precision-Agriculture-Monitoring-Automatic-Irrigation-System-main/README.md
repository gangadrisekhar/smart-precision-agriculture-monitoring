#Smart Precision Agriculture Monitoring & Automated Irrigation System

An embedded IoT-based agriculture monitoring and automated irrigation system developed using the NXP LPC2129 ARM7 microcontroller and Embedded C.

The system monitors soil moisture, water level, temperature, light intensity, rain, flame, and movement conditions. Based on the sensor readings, the LPC2129 processes the data and controls the irrigation pump while providing local monitoring through a 16×2 LCD and communication through UART and ESP8266.

---

📌 Features

- Automatic irrigation based on soil moisture level
- Soil moisture monitoring using ADC
- Water-level monitoring for pump protection
- Temperature monitoring using LM35
- Light intensity monitoring using LDR
- Rain detection
- Flame/fire detection with buzzer and LED indication
- PIR-based movement detection
- 16×2 LCD for real-time status display
- DS1307 RTC for date and time
- AT24C256 EEPROM for non-volatile data storage
- ESP8266 Wi-Fi communication
- ThingSpeak IoT cloud connectivity
- Modular Embedded C driver architecture
- UART, I2C, SPI and CAN driver modules

---

⚙️ Working Principle

1. The LPC2129 initializes the required peripherals such as ADC, UART, I2C and LCD.
2. Sensor values are continuously monitored.
3. The soil moisture sensor value is obtained through the ADC and converted into a percentage.
4. If the soil moisture is below the defined dry threshold, the irrigation pump is switched ON.
5. When the soil moisture reaches the normal/wet range, the pump is switched OFF.
6. The water-level sensor checks the available water in the tank and prevents pump operation when the level is too low.
7. Temperature, light, rain, flame and PIR sensor conditions are monitored.
8. Important information is displayed on the 16×2 LCD.
9. UART is used for serial monitoring and ESP8266 communication.
10. ESP8266 provides Wi-Fi connectivity for ThingSpeak-based monitoring.
11. RTC and EEPROM are used for timekeeping and non-volatile data storage.

---

💧 Irrigation Control

The soil moisture sensor is connected to the LPC2129 ADC.

The ADC result is converted into a soil moisture percentage.

Soil Moisture| Condition| Pump
"< 30%"| Dry| ON
"30% – 70%"| Normal| OFF
"> 70%"| Wet| OFF

The current implementation uses the 30% threshold for detecting dry soil. The pump is switched OFF when the soil moisture reaches the normal/wet range.

---

🔥 Safety Monitoring

The system includes additional sensors for monitoring environmental and safety conditions.

Flame Sensor

Detects flame/fire conditions and provides:

- Red LED indication
- Buzzer indication
- LCD status message
- UART status message

Rain Sensor

Detects rainfall conditions and provides rain status information.

Water-Level Sensor

Monitors the tank/reservoir level and helps prevent pump operation when the available water level is low.

PIR Sensor

Detects movement in the monitored area.

---

📡 Communication Interfaces

UART

Used for:

- Serial debugging
- Sensor status messages
- ESP8266 communication

I2C

Used for interfacing with:

- DS1307 RTC
- EEPROM

SPI

An SPI driver is included for SPI-based peripheral communication.

CAN

A CAN1 driver is included for CAN communication.

---

☁️ IoT Connectivity

The system uses an ESP8266 Wi-Fi module to provide IoT connectivity.

LPC2129
   │
 UART
   │
   ▼
ESP8266
   │
 Wi-Fi
   │
   ▼
ThingSpeak

The ESP8266 is controlled using AT commands through UART communication.

Sensor/system information can be sent to the ThingSpeak IoT platform for remote monitoring.

«Security: Wi-Fi passwords and ThingSpeak API keys should not be stored directly in a public GitHub repository. Use placeholders or a separate configuration method.»

---

🛠️ Hardware Used

- NXP LPC2129 ARM7 Microcontroller
- Soil Moisture Sensor
- Water-Level Sensor
- LM35 Temperature Sensor
- LDR Sensor
- Rain Sensor
- Flame Sensor
- PIR Sensor
- 16×2 LCD
- Relay Module
- Water Pump
- Buzzer
- LEDs
- ESP8266 Wi-Fi Module
- DS1307 RTC
- AT24C256 EEPROM
- SD-card interface

---

💻 Software & Technologies

- Programming Language: Embedded C
- Microcontroller: NXP LPC2129
- Processor: ARM7TDMI-S
- IDE: Keil µVision
- Programming Tool: Flash Magic
- IoT Platform: ThingSpeak
- Wi-Fi Module: ESP8266
- Protocols: UART, I2C, SPI, CAN

---

📂 Project Structure

File| Description
"header.h"| Common macros, pin definitions and function declarations
"pract.c"| Main application program
"adc_driver.c"| ADC initialization and ADC reading
"soil_sensor.c"| Soil moisture monitoring and pump control
"water_sensor.c"| Water-level monitoring
"LM35_Temp_sensor.c"| Temperature sensor interface
"LDR_sensor.c"| LDR/light monitoring
"rain_sensor.c"| Rain detection
"flame_sensor.c"| Flame detection and alarm indication
"PIR_sensor.c"| PIR movement detection
"lcd_4bitdriver.c"| 16×2 LCD driver
"uart0_driver.c"| UART0 communication driver
"wifi.c"| ESP8266 Wi-Fi communication
"I2c_driver.c"| I2C communication driver
"rtc.c"| DS1307 RTC interface
"EEPROM_driver.c"| EEPROM read/write functions
"spi_driver.c"| SPI communication driver
"can1_driver.c"| CAN1 communication driver
"delay_ms.c"| Delay functions

---

✅ Advantages

- Reduces unnecessary water usage.
- Provides automatic irrigation control.
- Monitors multiple agricultural parameters.
- Provides local monitoring through LCD.
- Supports IoT-based remote monitoring.
- Provides pump protection based on water availability.
- Includes fire and environmental monitoring.
- Demonstrates practical ARM7 Embedded C programming.
- Uses modular peripheral drivers.

---

⚠️ Limitations

- Sensor readings depend on proper sensor calibration.
- Current irrigation control uses fixed threshold values.
- CAN and SPI drivers are included but are not part of the active main control flow.
- IoT communication depends on Wi-Fi availability.
- The system is designed for the specific LPC2129 hardware and connected sensor configuration.

---

🚀 Future Scope

- Implement configurable irrigation thresholds.
- Add proper hysteresis to reduce unnecessary relay switching.
- Improve sensor calibration and filtering.
- Add SD-card based data logging.
- Add mobile application support.
- Provide real-time alerts for critical conditions.
- Integrate CAN communication into the main application.
- Improve cloud-based data visualization.
- Add automatic scheduling based on RTC and environmental conditions.

---

🎯 Skills Demonstrated

This project demonstrates practical knowledge of:

- Embedded C
- ARM7 LPC2129
- GPIO
- ADC
- UART
- I2C
- SPI
- CAN
- Sensor interfacing
- LCD interfacing
- RTC
- EEPROM
- ESP8266
- IoT communication
- Relay and pump control
- Embedded system debugging

---



GitHub Repository

"Smart Precision Agriculture Monitoring & Automated Irrigation System" (https://github.com/srinidhi084/Smart-Precision-Agriculture-Monitoring-Automatic-Irrigation-System)
