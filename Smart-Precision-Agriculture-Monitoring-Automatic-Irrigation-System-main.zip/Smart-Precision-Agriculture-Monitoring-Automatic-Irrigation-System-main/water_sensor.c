#include <lpc21xx.h>

#include "header.h"


int Water_sensor(void)

{

    unsigned int adcout, level;


    /* Read ADC Channel 2 */

    adcout = adc_read(2);


    level = (adcout * 100) / 1023;


    uart0_tx_string("Water Level : ");

    uart0_tx_integer(level);

    uart0_tx_string("%\r\n");


    if(level < 30)

    {

        /* LOW WATER LEVEL */

        uart0_tx_string("Tank Status : LOW\r\n");

        uart0_tx_string("Pump Status : OFF\r\n");


        /* yellow LED ON */

        IOCLR0 = yellow;

        IOSET0 = green | red;


        /* Pump OFF (active LOW relay) */

        IOSET0 = pump;


        lcd_cmd(0x01);

        lcd_cmd(0x80);

        lcd_string("Water : LOW");


        lcd_cmd(0xC0);

        lcd_string("Pump : OFF");

    }

    else if(level < 70)

    {

        /* NORMAL LEVEL */

        uart0_tx_string("Tank Status : NORMAL\r\n");

        uart0_tx_string("Pump Status : READY\r\n");


        /* green LED ON */

        IOCLR0 = green;

        IOSET0 = yellow | red;


        /* Pump OFF */

        IOSET0 = pump;


        lcd_cmd(0x01);

        lcd_cmd(0x80);

        lcd_string("Water : NORMAL");


        lcd_cmd(0xC0);

        lcd_string("Pump : READY");

    }

    else

    {

        /* FULL TANK */

        uart0_tx_string("Tank Status : FULL\r\n");

        uart0_tx_string("Pump Status : READY\r\n");


        /* Green LED ON */

        IOCLR0 = green;

        IOSET0 = yellow | red;


        /* Pump OFF */

        IOSET0 = pump;


        lcd_cmd(0x01);

        lcd_cmd(0x80);

        lcd_string("Water : FULL");


        lcd_cmd(0xC0);

        lcd_string("Pump : READY");

    }


    uart0_tx_string("-----------------------------------\r\n");


    delay_ms(100);

		return level;

}

