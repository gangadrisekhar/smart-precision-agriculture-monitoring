#include <lpc21xx.h>

#include "header.h"


int Soil_sensor(void)

{

    unsigned int adcout;

    unsigned int moisture;


    /* Read ADC Channel 0 */

    adcout = adc_read(0);
    moisture = (adcout * 100) / 1023;
    uart0_tx_string("Soil Moisture = ");

    uart0_tx_integer(moisture);

    uart0_tx_string("%\r\n");

	if(moisture < 30)
    {
        /* DRY */
        uart0_tx_string("Soil Status : DRY\r\n");

        uart0_tx_string("Pump Status : ON\r\n");
        /* Yellow LED ON */
        IOCLR0 = yellow;
        IOSET0 = green | red;
        /* Pump ON (active LOW relay) */
        IOCLR0 = pump;


        lcd_cmd(0x01);

        lcd_cmd(0x80);

        lcd_string("Soil : DRY");


        lcd_cmd(0xC0);

        lcd_string("Pump : ON");

    }

    else if(moisture>=30 && moisture <= 70)

    {

        /* NORMAL */

        uart0_tx_string("Soil Status : NORMAL\r\n");

        uart0_tx_string("Pump Status : OFF\r\n");


        /* Green LED ON */

        IOCLR0 = green;

        IOSET0 = yellow | red;


        /* Pump OFF */

        IOSET0 = pump;


        lcd_cmd(0x01);

        lcd_cmd(0x80);

        lcd_string("Soil : NORMAL");


        lcd_cmd(0xC0);

        lcd_string("Pump : OFF");

    }

    else 

    {

        /* WET */

        uart0_tx_string("Soil Status : WET\r\n");

        uart0_tx_string("Pump Status : OFF\r\n");


        /* Green LED ON */

        IOCLR0 = green;

        IOSET0 = yellow | red;


        /* Pump OFF */

        IOSET0 = pump;


        lcd_cmd(0x01);

        lcd_cmd(0x80);

        lcd_string("Soil : WET");


        lcd_cmd(0xC0);

        lcd_string("Pump : OFF");

    }


    uart0_tx_string("-----------------------------------\r\n");


    delay_ms(100);
	return moisture;

}
