#include <lpc21xx.h>

#include "header.h"


int Temp_sensor(void)

{

    unsigned int adcout = 0;

    unsigned int centigrade = 0;


    // ADC Channel 3 p

    adcout = adc_read(3);


   

    centigrade = (adcout * 330) / 1023;


  

    uart0_tx_string("\r\n----------------------\r\n");

    uart0_tx_string("Temperature : ");

    uart0_tx_integer(centigrade);

    uart0_tx_string(" C\r\n");


   

    if (centigrade >= 20 && centigrade <= 30)

    {

        /* NORMAL STATE */

        IOCLR0 = green;

        IOSET0 = red | yellow | BUZZER;


        uart0_tx_string("Status : NORMAL\r\n");

    }

    else if (centigrade > 30 && centigrade <= 50)

    {

        /* HIGH STATE */

        IOCLR0 = yellow;

        IOSET0 = green | red | BUZZER;


        uart0_tx_string("Status : HIGH\r\n");

    }

    else if (centigrade < 20)

    {

        /* LOW STATE */

        IOCLR0 = red;

        IOSET0 = green | yellow | BUZZER;


        uart0_tx_string("Status : LOW\r\n");

    }

    else

    {

        /* CRITICAL STATE (> 50�C) */

        IOCLR0 = red | BUZZER;

        IOSET0 = green | yellow;


        uart0_tx_string("Status : CRITICAL\r\n");

    }


    uart0_tx_string("----------------------\r\n");


    return centigrade;

}

